﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("RazorEngine: Core")]
[assembly: AssemblyDescription("Provides templating services using the Razor parser and code generator.")]

[assembly: Guid("e38fdd39-0ae9-4c67-af72-79191d7a1f85")]
