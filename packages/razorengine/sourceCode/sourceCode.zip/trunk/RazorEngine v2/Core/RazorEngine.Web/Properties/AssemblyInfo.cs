﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("RazorEngine: Web Compiler Services")]
[assembly: AssemblyDescription("Provides compilation services for Razor templates for ASP.NET scenarios.")]

[assembly: Guid("880b6642-911a-44f7-bf08-dba2417e939b")]
