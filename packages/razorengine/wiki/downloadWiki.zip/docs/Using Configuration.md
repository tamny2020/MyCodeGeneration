# Using Configuration
RazorEngine supports configuration through the standard .NET configuration framework. This page discuss what can be configured.

## Adding the configuration section.
To start using configuration, you need to add the configSection:

{code:xml}
<?xml version="1.0" encoding="UTF-8" ?>
<configuration>
    <configSections>
        <section name="razorEngine" type="RazorEngine.Configuration.RazorEngineConfigurationSection, RazorEngine" requirePermission="false" />
    </configSections>
</configuration>
{code:xml}

## The <razorEngine> element
The <razorEngine> element is the root of RazorEngine's configuration. The following attributes are supported:
|| Attribute Name || Required? || Default || Purpose ||
| activator | false | RazorEngine.Templating.DefaultActivator | Sets the default IActivator type for RazorEngine |
| factory | false | RazorEngine.Compilation.DefaultCompilerServiceFactory | Sets the ICompilerServiceFactory type for RazorEngine |

The <razorEngine> element supports for the following elements:
|| Element Name || Required? || Default || Purpose ||
| namespaces | false | | Defines the global namespace imports used for all templates |
| templateServices | false | | Defines configurations for instances of TemplateService |

An example configuration could be:
{code:xml}
    <razorEngine activator="RazorEngineSamples.Activators.MySampleActivator, RazorEngineSamples"
                 factory="RazorEngine.Web.WebCompilerServiceFactory, RazorEngine.Web">
        <namespaces>
            <add namespace="System.Linq" />
        </namespaces>
        <templateServices>
            <add ...
        </templateServices>
    </razorEngine>
{code:xml}

## Configuring TemplateService instances.
RazorEngine allows you to pre-configure instances of TemplateService which are then made available to your code.  The <add> element supports the following attributes:
|| Attribute Name || Required? || Default || Purpose ||
| activator | false | RazorEngine.Templating.DefaultActivator | Sets the activator type for the template service |
| language | false | CSharp | Sets the code language that the template is to support. This is an enum value of CSharp, VisualBasic. |
| markupParser | false | System.Web.Razor.Parser.HtmlMarkupParser | Sets the markup parser type for the template service. The default is **HtmlMarkupParser** |
| name | true | | Sets the name of the template service. |
| namespaces | false | | Sets the collection of namespaces imports for this template service. |
| strictMode | false | false | Sets whether the template will run in strict mode - this will cause parsing exceptions to be thrown for invalid markup. |
| templateBase | false | | Sets the template base type for this template service. |

## Accessing configured template services
Any template service configured through the <templateServices> element using the Razor.Services property. The Services property is an IDictionarty<string, TemplateService> instance using the configured _name_ as the key.
{code:xml}
    <razorEngine>
        <templateServices>
            <add name="myCustomTemplateService" language="CSharp" />
        </templateServices>
    <razorEngine>
{code:xml}
{code:c#}
var service = Razor.Services["myCustomTemplateService"](_myCustomTemplateService_);
string result = service.Parse("Hello @Model.Name", new { Name = "World" });
{code:c#}

## Setting the default TemplateService
You can change the default TemplateService instance by using the `default` attribute on the <templateServices> element:
{code:xml}
    <razorEngine>
        <templateServices default="myCustomTemplateService">
            <add name="myCustomTemplateService" ...
        </templateServices>
    </razorEngine>
{code:xml}

This will enforce that when using calls from the Razor static type, it will use your default template service. If you do not set the default template service, calls to the Razor type methods will use the internal configured default instance, which uses the C# code language and the HtmlMarkupParser.