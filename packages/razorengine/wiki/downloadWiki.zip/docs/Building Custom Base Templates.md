# Building Custom Base Templates

When the Razor parser is processing the content of your Razor view, it's actually generating the code of a method (Execute) as a series of Write statements.  In the exact same way, this templating engine is creating a class at runtime that inherits from a type that supports Execute and Write operations.  The default implementation, TemplateBase (or TemplateBase<T> when using a model) is what we use to create simple templates, e.g:

{code:c#}
string template = "This is my sample template, Hello @Model.Name!";
string result = Razor.Parse(template, new { Name = "World"  });
{code:c#}

Will result in something similar to:

{code:c#}
public class asdascasca : RazorEngine.Templating.TemplateBase<dynamic>
{
  ...
  public void Execute()
  {
    this.Clear();
    WriteLiteral("This is my sample template, Hello ");
    Write(Model.Name);
    WriteLiteral("!");
  }
}
{code:c#}

A question I get often asked is where is my @Html support? Much like @Model, @Html is a property of the base WebViewPage in MVC.  Out of the box, Razor doesn't actually support it.  If I wanted to introduce support for custom properties or methods, I would need to create a custom base template. Here's an example:

{code:c#}
public abstract class MyCustomTemplateBase<T> : TemplateBase<T>
{
  public string ToUpperCase(string name)
  {
    return name.ToUpperCase();
  }
}
{code:c#}

To use this custom template base, I need to tell the TemplateService hosted by the Razor static class to use it:

{code:c#}
Razor.SetTemplateBase(typeof(MyCustomTemplateBase<>));
{code:c#}

And then we can fire some code at it:

{code:c#}
string template = "My name in UPPER CASE is: @ToUpperCase(Model.Name)";
string result = Razor.Parse(template, new { Name = "Matt" });
{code:c#}

We are looking at ways of improving support for base templates in the future.