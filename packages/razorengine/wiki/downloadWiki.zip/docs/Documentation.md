# Documentation

* [Quick Start Guide](Quick-Start-Guide)
* [Architecture](Architecture)
* [Building Custom Base Templates](Building-Custom-Base-Templates)
* [Using Configuration](Using-Configuration)
* [Configuring RazorEngine for ASP.NET Medium Trust](Configuring-RazorEngine-for-ASP.NET-Medium-Trust)