# Configuring RazorEngine for ASP.NET Medium Trust

ASP.NET in Medium Trust does not allow direct instantiation of CodeDomProvider instances.  This means we need to use ASP.NET's BuildProvider model to defer compilation to the build system.  **To do this, you need to add a reference to RazorEngine.Web to your project.**

## Step 1 - Wire up the RazorVirtualPathProvider

You need to register the RazorVirtualPathProvider to allow the BuildManager to make calls to virtual Razor file paths.

{code:C#}
protected void Application_Start()
{
    HostingEnvironment.RegisterVirtualPathProvider(new RazorVirtualPathProvider());
}
{code:C#}

## Step 2 - Add the RazorEngine configuration section

There are a specialised set of compiler services for Medium trust scenarios.  We need to use the WebCompilerServiceFactory which is used to create these services.

{code:xml}
<configuration>
    <configSections>
        <section name="razorEngine" type="RazorEngine.Configuration.RazorEngineConfigurationSection, RazorEngine" requirePermission="false" />
    </configSections>

    <razorEngine factory="RazorEngine.Web.WebCompilerServiceFactory, RazorEngine.Web" />
</configuration>
{code:xml}

## Step 3 - Configure the BuildProviders

We map calls to virtual paths ending in ".csrzr" and ".vbrzr" to allow our BuildProvider to intercept and build the types. We don't use the Razor MVC file extensions (".cshtml", ".vbhtml") as we do not want to conflict with an existing MVC 3 application.

{code:xml}
<configuration>
    <system.web>
        <buildProviders>
            <add extension=".csrzr" type="RazorEngine.Web.CSharp.CSharpRazorBuildProvider, RazorEngine.Web" />
            <add extension=".vbrzr" type="RazorEngine.Web.VisualBasic.VBRazorBuildProvider, RazorEngine.Web" />
        </buildProviders>
    </system.web>
</configuration>
{code:xml}

You should now be able to make calls to parsing methods in your web application.